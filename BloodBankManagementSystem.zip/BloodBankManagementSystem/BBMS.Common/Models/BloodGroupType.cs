﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Common.Models
{
    public class BloodGroupType:BBMSBase
    {
        public string? GroupName { get; set; } 
        public long BloodUnits { get; set; }
    }
}
