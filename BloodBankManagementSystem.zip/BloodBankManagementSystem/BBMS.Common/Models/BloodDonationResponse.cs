﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Common.Models
{
    public class BloodDonationResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public BloodDonation _bloodDonation { get; set; } = new BloodDonation();
        public List<BloodDonation> _bloodDonations { get; set; } = new List<BloodDonation>();
    }
}
