﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Common.Models
{
    public class UserRoleResponse
    {
        public string? Status { get; set; }
        public string? Msg { get; set; }
        public UserRole _UserRole { get; set; } = new UserRole();
        public List<UserRole> _userRoles { get; set; } = new List<UserRole>();
    }
}
