﻿using BBMS.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.IRepository
{
    public interface IBloodDonation
    {
        BloodDonationResponse GetAllBloodDonars();
        BloodDonationResponse GetBloodDonar(int id);
        BloodDonationResponse AddBloodDonar(BloodDonation _bloodDonation);
        BloodDonationResponse UpdateBloodDonar(BloodDonation _bloodDonation);
        BloodDonationResponse DeleteBloodDonar(BloodDonation _bloodDonation);
    }
}
