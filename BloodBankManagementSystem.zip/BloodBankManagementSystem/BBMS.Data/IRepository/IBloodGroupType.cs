﻿using BBMS.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.IRepository
{
    public interface IBloodGroupType
    {
        BloodGroupTypeResponse GetAllBloodGroupTypes();
        BloodGroupTypeResponse GetBloodGroupType(int id);
        BloodGroupTypeResponse AddBloodGroupType(BloodGroupType _bloodGroupType);
        BloodGroupTypeResponse UpdateBloodGroupType(BloodGroupType _bloodGroupType);
        BloodGroupTypeResponse DeleteBloodGroupType(BloodGroupType _bloodGroupType);
    }
}
