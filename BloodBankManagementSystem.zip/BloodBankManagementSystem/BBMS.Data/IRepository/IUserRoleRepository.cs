﻿using BBMS.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.IRepository
{
    public interface IUserRoleRepository
    {
        UserRoleResponse GetAllUserRole();
        UserRoleResponse GetUserRole(int id);
        UserRoleResponse AddUserRole(UserRole _userRoles);
        UserRoleResponse UpdateUserRole(UserRole _userRoles);
        UserRoleResponse DeleteUserRole(UserRole _userRoles);
    }
}
