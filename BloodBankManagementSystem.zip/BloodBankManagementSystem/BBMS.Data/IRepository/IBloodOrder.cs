﻿using BBMS.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.IRepository
{
    public interface IBloodOrder
    {
        BloodOrderResponse GetAllBloodOrders();
        BloodOrderResponse GetBloodOrder(int id);
        BloodOrderResponse AddBloodOrder(BloodOrder _bloodOrder);
        BloodOrderResponse UpdateBloodOrder(BloodOrder _bloodOrder);
        BloodOrderResponse DeleteBloodOrder(BloodOrder _bloodOrder);
    }
}
