﻿using BBMS.Common.Login;
using BBMS.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.IRepository
{
    public interface IUserManagement
    {
        /// <summary>
        /// User Management Mechanism
        /// </summary>
        /// <returns></returns>
        UserManagementResponse GetAllUserManagements();
        UserManagementResponse GetUserManagement(int id);
        UserManagementResponse AddUserManagement(UserManagement _userManagement);
        UserManagementResponse UpdateUserManagement(UserManagement _userManagement);
        UserManagementResponse DeleteUserManagement(UserManagement _userManagement);

        /// <summary>
        /// Login Mechanism
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        LoginReponse GetUserLogin(LoginVM Input);
    }
}
