﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Data.Migrations
{
    public partial class V1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "UserRoles",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RoleId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserManagements",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserRoleRoleId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserRoleId = table.Column<long>(type: "bigint", nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PrimaryMobile = table.Column<long>(type: "bigint", nullable: false),
                    SecondaryMobile = table.Column<long>(type: "bigint", nullable: true),
                    PrimaryEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecondaryEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PinCode = table.Column<long>(type: "bigint", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PassWord = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserManagements", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserManagements_UserRoles_UserRoleId",
                        column: x => x.UserRoleId,
                        principalTable: "UserRoles",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "UserRoles",
                columns: new[] { "Id", "CreatedBy", "CreatedOn", "IsDeleted", "ModifiedBy", "ModifiedOn", "OrderBy", "RoleId", "RoleName", "RowId" },
                values: new object[,]
                {
                    { 1L, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7316), false, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7327), 0, "1EA44CE7-667B-436A-982D-D419E74DE322", "Administrator", "fac6bb1a-095f-40f2-9ab3-cff2a64b8383" },
                    { 2L, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7337), false, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7338), 0, "95117A42-6456-46A5-8ACB-0E0B0E0E8A96", "Staff", "af8d4b95-ddc7-4d41-bc5f-e4d0ce2d7fc8" },
                    { 3L, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7342), false, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7343), 0, "AAC21712-38EA-4CF7-A1BE-ACC0AEAEF72C", "Donor", "48511f28-b735-47e4-baf9-1873a108e145" },
                    { 4L, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7347), false, "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7348), 0, "31C2282F-40E7-4A58-86FB-DCD73ADD4C01", "User", "0ecc4857-0a53-4266-a693-192effdb1a0e" }
                });

            migrationBuilder.InsertData(
                table: "UserManagements",
                columns: new[] { "Id", "Address1", "Address2", "Address3", "CreatedBy", "CreatedOn", "FirstName", "IsDeleted", "LastName", "MiddleName", "ModifiedBy", "ModifiedOn", "OrderBy", "PassWord", "PinCode", "PrimaryEmail", "PrimaryMobile", "RowId", "SecondaryEmail", "SecondaryMobile", "UserName", "UserRoleId", "UserRoleRoleId" },
                values: new object[] { 1L, "Administrator", "Administrator", "Administrator", "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7511), "Administrator", false, "Administrator", "Administrator", "Administrator", new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7512), 0, "Admin", 111111L, "Administrator@gmail.com", 1234567890L, "9cc6d5d4-16ae-409a-a13f-b77d379cd676", "Administrator@gmail.com", 1234567890L, "Admin", 1L, "1EA44CE7-667B-436A-982D-D419E74DE322" });

            migrationBuilder.CreateIndex(
                name: "IX_UserManagements_UserRoleId",
                table: "UserManagements",
                column: "UserRoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UserManagements");

            migrationBuilder.DropTable(
                name: "UserRoles");
        }
    }
}
