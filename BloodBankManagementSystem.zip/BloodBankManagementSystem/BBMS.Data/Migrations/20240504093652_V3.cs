﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Data.Migrations
{
    public partial class V3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BloodDonations",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserManagementRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserManagementId = table.Column<long>(type: "bigint", nullable: true),
                    BloodGroupTypeRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BloodGroupTypeId = table.Column<long>(type: "bigint", nullable: true),
                    DonationDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsDonarSubmitted = table.Column<bool>(type: "bit", nullable: false),
                    NumberofUnits = table.Column<long>(type: "bigint", nullable: false),
                    RBCCount = table.Column<long>(type: "bigint", nullable: false),
                    WBCCount = table.Column<long>(type: "bigint", nullable: false),
                    PlateletsCount = table.Column<long>(type: "bigint", nullable: false),
                    IsDonationDone = table.Column<bool>(type: "bit", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodDonations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BloodDonations_BloodGroupTypes_BloodGroupTypeId",
                        column: x => x.BloodGroupTypeId,
                        principalTable: "BloodGroupTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_BloodDonations_UserManagements_UserManagementId",
                        column: x => x.UserManagementId,
                        principalTable: "UserManagements",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "BloodOrders",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserManagementRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserManagementId = table.Column<long>(type: "bigint", nullable: true),
                    BloodGroupTypeRowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BloodGroupTypeId = table.Column<long>(type: "bigint", nullable: true),
                    NoOfUnitsAvailable = table.Column<long>(type: "bigint", nullable: false),
                    NoOfUnitsRequired = table.Column<long>(type: "bigint", nullable: false),
                    UserRequested = table.Column<bool>(type: "bit", nullable: false),
                    UserCancelled = table.Column<bool>(type: "bit", nullable: false),
                    PaymentRecieved = table.Column<bool>(type: "bit", nullable: false),
                    StaffProcessed = table.Column<bool>(type: "bit", nullable: false),
                    StaffCancelled = table.Column<bool>(type: "bit", nullable: false),
                    SampleOutFordelivery = table.Column<bool>(type: "bit", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodOrders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BloodOrders_BloodGroupTypes_BloodGroupTypeId",
                        column: x => x.BloodGroupTypeId,
                        principalTable: "BloodGroupTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_BloodOrders_UserManagements_UserManagementId",
                        column: x => x.UserManagementId,
                        principalTable: "UserManagements",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "InventoryDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InventoryNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InventoryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InventoryDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrdeDeliveryDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OutFordelivery = table.Column<bool>(type: "bit", nullable: false),
                    OutFordeliveryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeliveryPersonDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    delivered = table.Column<bool>(type: "bit", nullable: false),
                    DeliveryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeliveryOTP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrdeDeliveryDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrdeDeliveryDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PaymentDetail",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PaymentRecieved = table.Column<bool>(type: "bit", nullable: false),
                    PaymentCancelled = table.Column<bool>(type: "bit", nullable: false),
                    PaymentDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PaymentAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TransactionNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransactionCardDetails = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodOrderId = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PaymentDetail_BloodOrders_BloodOrderId",
                        column: x => x.BloodOrderId,
                        principalTable: "BloodOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1698), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1699), "df558394-db72-48bd-bbb8-2767651ac6f9" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1718), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1720), "4a049b1b-0adb-418f-96f9-790bad7ec35f" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1724), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1725), "fa08e746-29bc-4c09-a64e-4b9af282181e" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1730), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1731), "4010e51f-e42c-4303-ae38-1f397fb816c7" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1734), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1735), "0f0ee2c5-0bc3-4ad5-9fe0-b9d93203908f" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1739), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1739), "d0eab4e9-f7dc-425c-95d5-6025ff67c179" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1745), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1746), "243334e1-78f6-4d29-be5e-2637f4a378ef" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1752), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1755), "45eea638-75eb-4a20-9d28-713b5c4dfc9c" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1664), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1667), "6661b492-2400-41d4-8a6e-82597c8a7e03" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1457), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1467), "193915c0-d49c-4698-8aeb-29034b564075" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1474), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1476), "8b23dce7-f6b3-4275-95d1-1ccd132d0576" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1480), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1481), "43f2ee60-05b4-41ea-9945-a93ef98e6436" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1488), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1488), "55d794d4-5b4a-4059-a27a-bb999d01dcab" });

            migrationBuilder.CreateIndex(
                name: "IX_BloodDonations_BloodGroupTypeId",
                table: "BloodDonations",
                column: "BloodGroupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodDonations_UserManagementId",
                table: "BloodDonations",
                column: "UserManagementId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodOrders_BloodGroupTypeId",
                table: "BloodOrders",
                column: "BloodGroupTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_BloodOrders_UserManagementId",
                table: "BloodOrders",
                column: "UserManagementId");

            migrationBuilder.CreateIndex(
                name: "IX_InventoryDetail_BloodOrderId",
                table: "InventoryDetail",
                column: "BloodOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OrdeDeliveryDetail_BloodOrderId",
                table: "OrdeDeliveryDetail",
                column: "BloodOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PaymentDetail_BloodOrderId",
                table: "PaymentDetail",
                column: "BloodOrderId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BloodDonations");

            migrationBuilder.DropTable(
                name: "InventoryDetail");

            migrationBuilder.DropTable(
                name: "OrdeDeliveryDetail");

            migrationBuilder.DropTable(
                name: "PaymentDetail");

            migrationBuilder.DropTable(
                name: "BloodOrders");

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(236), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(237), "1cf7f362-7a97-4146-9c05-2b1b78d17424" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(240), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(241), "000ea072-6257-47dc-94d6-94b4ad9e0a85" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(243), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(244), "477ec287-28ec-4ce6-90b6-e230e75da904" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(247), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(247), "0b1c44dc-c9d2-4a71-a51d-1be33e1e69df" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(250), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(251), "b70d3ce1-79af-425b-a1cd-fdbbba9e6b82" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(257), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(257), "c80748d8-80c9-46d2-b8ac-4bd8508e6cbe" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(260), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(261), "797ee083-8ac3-437d-ad10-83d3f2549a12" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(263), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(264), "f30fd2d4-d4f4-418d-9f82-e5c5f3ad2e18" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(215), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(216), "dc70513a-4594-48eb-9fcc-b320fbacae37" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(78), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(87), "52fb8456-3b20-4b14-9dd0-b19ef003dbe0" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(92), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(92), "64d5d537-2917-4787-849e-1934241f87cf" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(110), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(110), "1109ba27-e63b-4825-bd05-a24293f0f0ca" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(113), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(114), "6a6d3860-544f-4b67-83f7-718a4d6dc14c" });
        }
    }
}
