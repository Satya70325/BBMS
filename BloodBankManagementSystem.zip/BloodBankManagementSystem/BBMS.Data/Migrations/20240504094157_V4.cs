﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Data.Migrations
{
    public partial class V4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserRoleRoleId",
                table: "UserManagements",
                newName: "UserRoleRowId");

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(90), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(91), "861f6775-a6ad-449e-b583-9f46a12fba0a" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(103), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(104), "756f02d7-d32d-41c5-9e90-d80d2269f398" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(107), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(107), "6ad0de2d-dc4a-4eb6-8944-fb8af73dbdd3" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(110), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(111), "a04d25aa-12da-4407-9a3b-2d1f9014176b" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(113), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(114), "4a078b2d-ba4b-42ba-8d18-8c6f83a88f18" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(116), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(117), "126b5eea-c1d4-4055-9f25-2f5522c66eab" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(119), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(120), "412e7ac8-ee5e-4be2-bfbe-fc92a3d1337c" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(123), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(123), "4f19a336-458a-444e-8c4f-c3b02c4e5b82" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(66), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(67), "0b0ce738-04a5-49b3-9459-67d9b5da24bf" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9934), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9945), "b003dd7f-1820-4ae2-b5cf-05017c2ccfb1" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9951), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9952), "08dfbf6f-bf9d-46b6-9561-5204aac51271" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9955), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9955), "cd66e996-1177-4bcd-b8a2-adb3ddebe786" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9958), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9959), "adb06b9d-8ed0-4174-99e7-6149ebe80389" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserRoleRowId",
                table: "UserManagements",
                newName: "UserRoleRoleId");

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1698), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1699), "df558394-db72-48bd-bbb8-2767651ac6f9" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1718), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1720), "4a049b1b-0adb-418f-96f9-790bad7ec35f" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1724), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1725), "fa08e746-29bc-4c09-a64e-4b9af282181e" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1730), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1731), "4010e51f-e42c-4303-ae38-1f397fb816c7" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1734), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1735), "0f0ee2c5-0bc3-4ad5-9fe0-b9d93203908f" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1739), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1739), "d0eab4e9-f7dc-425c-95d5-6025ff67c179" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1745), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1746), "243334e1-78f6-4d29-be5e-2637f4a378ef" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1752), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1755), "45eea638-75eb-4a20-9d28-713b5c4dfc9c" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1664), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1667), "6661b492-2400-41d4-8a6e-82597c8a7e03" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1457), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1467), "193915c0-d49c-4698-8aeb-29034b564075" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1474), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1476), "8b23dce7-f6b3-4275-95d1-1ccd132d0576" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1480), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1481), "43f2ee60-05b4-41ea-9945-a93ef98e6436" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1488), new DateTime(2024, 5, 4, 15, 6, 52, 228, DateTimeKind.Local).AddTicks(1488), "55d794d4-5b4a-4059-a27a-bb999d01dcab" });
        }
    }
}
