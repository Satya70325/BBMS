﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Data.Migrations
{
    public partial class V2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BloodGroupTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BloodUnits = table.Column<long>(type: "bigint", nullable: false),
                    RowId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    OrderBy = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BloodGroupTypes", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "BloodGroupTypes",
                columns: new[] { "Id", "BloodUnits", "CreatedBy", "CreatedOn", "GroupName", "IsDeleted", "ModifiedBy", "ModifiedOn", "OrderBy", "RowId" },
                values: new object[,]
                {
                    { 1L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(236), "A+", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(237), 0, "1cf7f362-7a97-4146-9c05-2b1b78d17424" },
                    { 2L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(240), "A-", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(241), 0, "000ea072-6257-47dc-94d6-94b4ad9e0a85" },
                    { 3L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(243), "B+", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(244), 0, "477ec287-28ec-4ce6-90b6-e230e75da904" },
                    { 4L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(247), "B-", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(247), 0, "0b1c44dc-c9d2-4a71-a51d-1be33e1e69df" },
                    { 5L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(250), "AB+", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(251), 0, "b70d3ce1-79af-425b-a1cd-fdbbba9e6b82" },
                    { 6L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(257), "AB-", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(257), 0, "c80748d8-80c9-46d2-b8ac-4bd8508e6cbe" },
                    { 7L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(260), "O+", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(261), 0, "797ee083-8ac3-437d-ad10-83d3f2549a12" },
                    { 8L, 0L, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(263), "O-", false, "Administrator", new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(264), 0, "f30fd2d4-d4f4-418d-9f82-e5c5f3ad2e18" }
                });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(215), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(216), "dc70513a-4594-48eb-9fcc-b320fbacae37" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(78), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(87), "52fb8456-3b20-4b14-9dd0-b19ef003dbe0" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(92), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(92), "64d5d537-2917-4787-849e-1934241f87cf" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(110), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(110), "1109ba27-e63b-4825-bd05-a24293f0f0ca" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(113), new DateTime(2024, 5, 4, 14, 54, 19, 150, DateTimeKind.Local).AddTicks(114), "6a6d3860-544f-4b67-83f7-718a4d6dc14c" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BloodGroupTypes");

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7511), new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7512), "9cc6d5d4-16ae-409a-a13f-b77d379cd676" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7316), new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7327), "fac6bb1a-095f-40f2-9ab3-cff2a64b8383" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7337), new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7338), "af8d4b95-ddc7-4d41-bc5f-e4d0ce2d7fc8" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7342), new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7343), "48511f28-b735-47e4-baf9-1873a108e145" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7347), new DateTime(2024, 5, 4, 14, 10, 24, 999, DateTimeKind.Local).AddTicks(7348), "0ecc4857-0a53-4266-a693-192effdb1a0e" });
        }
    }
}
