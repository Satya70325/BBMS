﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BBMS.Data.Migrations
{
    public partial class V5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1114), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1115), "aaa16352-ae87-4319-a624-e66c772a91cd" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1118), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1118), "9d2d1aee-b717-431c-b224-0427360e95c8" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1121), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1122), "40097d9b-557b-489e-b8da-caf78f6d2aff" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1125), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1126), "dc835a47-24d1-47be-bdd4-7386e2d49917" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1129), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1129), "6c8f9837-fd72-4d75-bf10-388225d74d05" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1136), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1136), "85a06376-f160-4933-9344-747e4b8bf4da" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1139), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1139), "4f7d051c-3b7b-472d-8df7-7320752b027e" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1142), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1143), "fdf75b82-1aec-4479-9a19-a6d7677b63b6" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1083), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(1085), "345ed852-18aa-4b9c-aee3-89faecc91497" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(887), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(896), "732bf81c-aeef-42f6-989e-7a1419c71f8a" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(903), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(904), "64c674af-644f-453d-89aa-bdc0c0dade7a" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(920), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(920), "e2c7ed33-d180-4e9c-8377-c576cd3a5078" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(924), new DateTime(2024, 5, 7, 15, 7, 23, 430, DateTimeKind.Local).AddTicks(924), "ff5c7ee7-d9b6-4e7d-9cad-6bfaaa724031" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(90), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(91), "861f6775-a6ad-449e-b583-9f46a12fba0a" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(103), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(104), "756f02d7-d32d-41c5-9e90-d80d2269f398" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(107), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(107), "6ad0de2d-dc4a-4eb6-8944-fb8af73dbdd3" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(110), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(111), "a04d25aa-12da-4407-9a3b-2d1f9014176b" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 5L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(113), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(114), "4a078b2d-ba4b-42ba-8d18-8c6f83a88f18" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 6L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(116), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(117), "126b5eea-c1d4-4055-9f25-2f5522c66eab" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 7L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(119), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(120), "412e7ac8-ee5e-4be2-bfbe-fc92a3d1337c" });

            migrationBuilder.UpdateData(
                table: "BloodGroupTypes",
                keyColumn: "Id",
                keyValue: 8L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(123), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(123), "4f19a336-458a-444e-8c4f-c3b02c4e5b82" });

            migrationBuilder.UpdateData(
                table: "UserManagements",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(66), new DateTime(2024, 5, 4, 15, 11, 56, 786, DateTimeKind.Local).AddTicks(67), "0b0ce738-04a5-49b3-9459-67d9b5da24bf" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 1L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9934), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9945), "b003dd7f-1820-4ae2-b5cf-05017c2ccfb1" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 2L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9951), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9952), "08dfbf6f-bf9d-46b6-9561-5204aac51271" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 3L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9955), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9955), "cd66e996-1177-4bcd-b8a2-adb3ddebe786" });

            migrationBuilder.UpdateData(
                table: "UserRoles",
                keyColumn: "Id",
                keyValue: 4L,
                columns: new[] { "CreatedOn", "ModifiedOn", "RowId" },
                values: new object[] { new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9958), new DateTime(2024, 5, 4, 15, 11, 56, 785, DateTimeKind.Local).AddTicks(9959), "adb06b9d-8ed0-4174-99e7-6149ebe80389" });
        }
    }
}
