﻿using BBMS.Common;
using BBMS.Common.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data
{
    public class BBMSDataContext : DbContext
    {
        public BBMSDataContext(DbContextOptions<BBMSDataContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<UserRole>().HasData(
            new UserRole
            {
                RoleName = "Administrator",
                Id = 1,
                RoleId = Constants.AdministratorRoleId,
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new UserRole
            {
                RoleName = "Staff",
                Id = 2,
                RoleId = Constants.StaffRoleId,
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new UserRole
            {
                RoleName = "Donor",
                Id = 3,
                RoleId = Constants.DonorRoleId,
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new UserRole
            {
                RoleName = "User",
                Id = 4,
                RoleId = Constants.UserRoleId,
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            });


            modelBuilder.Entity<UserManagement>().HasData(
            new UserManagement
            {
                Id=1,
                UserRoleRowId = Constants.AdministratorRoleId,
                UserRoleId=1,
                FirstName = "Administrator",
                MiddleName = "Administrator",
                LastName = "Administrator",
                PrimaryMobile = 1234567890,
                SecondaryMobile = 1234567890,
                PrimaryEmail = "Administrator@gmail.com",
                SecondaryEmail = "Administrator@gmail.com",
                Address1 = "Administrator",
                Address2 = "Administrator",
                Address3 = "Administrator",
                PinCode = 111111,
                UserName = "Admin",
                PassWord = "Admin",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            });

            modelBuilder.Entity<BloodGroupType>().HasData(
            new BloodGroupType
            {
                Id = 1,
                GroupName = "A+",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 2,
                GroupName = "A-",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 3,
                GroupName = "B+",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 4,
                GroupName = "B-",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 5,
                GroupName = "AB+",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 6,
                GroupName = "AB-",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 7,
                GroupName = "O+",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            },
            new BloodGroupType
            {
                Id = 8,
                GroupName = "O-",
                CreatedBy = "Administrator",
                ModifiedBy = "Administrator"
            });

           
        }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<UserManagement> UserManagements { get; set; }
        public DbSet<BloodGroupType> BloodGroupTypes { get; set; }
        public DbSet<BloodDonation> BloodDonations { get; set; }
        public DbSet<BloodOrder> BloodOrders { get; set; }

    }
}
