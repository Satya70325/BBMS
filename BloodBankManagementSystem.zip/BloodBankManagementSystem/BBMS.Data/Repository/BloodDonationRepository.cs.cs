﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.Repository
{
    public class BloodDonationRepository : IBloodDonation
    {
        private readonly BBMSDataContext _context;
        public BloodDonationRepository(BBMSDataContext context)
        {
            _context = context;
        }       

        public BloodDonationResponse GetAllBloodDonars()
        {
            BloodDonationResponse BloodDonationrsp = new BloodDonationResponse();
            try
            {
                List<BloodDonation> GetAllDonation = _context.BloodDonations.Where(s => !s.IsDeleted).ToList();

                if (GetAllDonation.Any())
                {
                    List<BloodDonation> response = GetAllDonation.Select(s => new BloodDonation()
                    {
                        Id = s.Id,
                        DonationDate = s.DonationDate,
                        IsDonarSubmitted = s.IsDonationDone,
                        NumberofUnits = s.NumberofUnits,
                        RBCCount = s.RBCCount,
                        WBCCount = s.WBCCount,
                        PlateletsCount = s.PlateletsCount,
                        IsDonationDone = s.IsDonationDone

                    }).ToList();
                    BloodDonationrsp._bloodDonations = response;
                }
                BloodDonationrsp.Status = "Success";
                BloodDonationrsp.Msg = "Success";
                return BloodDonationrsp;
            }
            catch (Exception)
            {

                BloodDonationrsp.Status = "Fail";
                BloodDonationrsp.Msg = "Fail";
                return BloodDonationrsp;
            }
        }

        public BloodDonationResponse GetBloodDonar(int id)
        {
            BloodDonationResponse BloodDonationrsp = new BloodDonationResponse();
            try
            {
                BloodDonation? GetData = _context.BloodDonations.Where(s => s.Id == id).AsQueryable().FirstOrDefault();
                if (GetData != null)
                {
                    BloodDonationrsp._bloodDonation = GetData;
                }
                BloodDonationrsp.Status = "Success";
                BloodDonationrsp.Msg = "Success";
                return BloodDonationrsp;
            }
            catch (Exception)
            {
                BloodDonationrsp.Status = "Fail";
                BloodDonationrsp.Msg = "Fail";
                return BloodDonationrsp;
            }

        }
        public BloodDonationResponse AddBloodDonar(BloodDonation _bloodDonation)
        {
            BloodDonationResponse BloodDonationrsp = new BloodDonationResponse();
            try
            {
                var AddBloodDonation = _context.BloodDonations.Add(_bloodDonation);
                _context.SaveChanges();
                BloodDonationrsp.Status = "Success";
                BloodDonationrsp.Msg = "Success";
                BloodDonationrsp._bloodDonation = AddBloodDonation.Entity;
                return BloodDonationrsp;
            }
            catch (Exception)
            {
                BloodDonationrsp.Status = "Fail";
                BloodDonationrsp.Msg = "Fail";
                return BloodDonationrsp;
            }

        }

        public BloodDonationResponse UpdateBloodDonar(BloodDonation _bloodDonation)
        {
            BloodDonationResponse BloodDonationrsp = new BloodDonationResponse();
            try
            {
                BloodDonation? UpdateData = _context.BloodDonations.Where(s => s.Id == _bloodDonation.Id).AsQueryable().FirstOrDefault();
                if (UpdateData != null)
                {
                    UpdateData.UserManagementRowId = _bloodDonation.UserManagementRowId;
                    UpdateData.UserManagementId = _bloodDonation.UserManagementId;
                    UpdateData.BloodGroupTypeRowId = _bloodDonation.BloodGroupTypeRowId;
                    UpdateData.BloodGroupTypeId = _bloodDonation.BloodGroupTypeId;
                    UpdateData.DonationDate = _bloodDonation.DonationDate;
                    UpdateData.IsDonarSubmitted = _bloodDonation.IsDonarSubmitted;
                    UpdateData.NumberofUnits = _bloodDonation.NumberofUnits;
                    UpdateData.RBCCount = _bloodDonation.RBCCount;
                    UpdateData.WBCCount = _bloodDonation.WBCCount;
                    UpdateData.PlateletsCount = _bloodDonation.PlateletsCount;
                    UpdateData.IsDonationDone = _bloodDonation.IsDonationDone;
                    UpdateData.IsDeleted = _bloodDonation.IsDeleted;
                    UpdateData.CreatedBy = _bloodDonation.CreatedBy;
                    UpdateData.ModifiedBy = _bloodDonation.ModifiedBy;
                    UpdateData.CreatedOn = _bloodDonation.CreatedOn;
                    UpdateData.ModifiedOn = _bloodDonation.ModifiedOn;
                    UpdateData.OrderBy = _bloodDonation.OrderBy;
                    _context.SaveChanges();
                }

                BloodDonationrsp.Status = "Success";
                BloodDonationrsp.Msg = "Success";
                BloodDonationrsp._bloodDonation = UpdateData;
                return BloodDonationrsp;
            }
            catch (Exception)
            {
                BloodDonationrsp.Status = "Fail";
                BloodDonationrsp.Msg = "Fail";
                return BloodDonationrsp;
            }

        }
        public BloodDonationResponse DeleteBloodDonar(BloodDonation _bloodDonation)
        {
            BloodDonationResponse BloodDonationrsp = new BloodDonationResponse();
            try
            {
                BloodDonation? DeleteData = _context.BloodDonations.Where(s => s.Id == _bloodDonation.Id).AsQueryable().FirstOrDefault();
                if (DeleteData != null)
                {
                    DeleteData.IsDeleted = true;
                    _context.SaveChanges();
                    BloodDonationrsp.Status = "Success";
                    BloodDonationrsp.Msg = "Success";
                    BloodDonationrsp._bloodDonation = DeleteData;
                    return BloodDonationrsp;
                }
                else
                {

                    BloodDonationrsp.Status = "Success";
                    BloodDonationrsp.Msg = "Data Not Found";
                    BloodDonationrsp._bloodDonation = DeleteData;
                    return BloodDonationrsp;
                }

            }
            catch (Exception)
            {

                BloodDonationrsp.Status = "Fail";
                BloodDonationrsp.Msg = "Fail";
                return BloodDonationrsp;
            }

        }
    }
}
