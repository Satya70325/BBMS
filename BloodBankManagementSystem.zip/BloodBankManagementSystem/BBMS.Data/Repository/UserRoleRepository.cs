﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.Repository
{
    public class UserRoleRepository : IUserRoleRepository
    {
        private readonly BBMSDataContext _context;
        public UserRoleRepository(BBMSDataContext context)
        {
            _context = context;

        }
       
        public UserRoleResponse GetAllUserRole()
        {
            UserRoleResponse Userrolersp = new UserRoleResponse();
            try
            {
                List<UserRole> GetAllUserRole = _context.UserRoles.Where(s=>!s.IsDeleted).ToList();
                
                if (GetAllUserRole.Any())
                {
                    List<UserRole> response = GetAllUserRole.Select(s=> new UserRole()
                    {
                        Id = s.Id,
                        RoleId = s.RoleId,
                        RoleName = s.RoleName
                    }).ToList();
                    Userrolersp._userRoles = response;
                }
                Userrolersp.Status = "Success";
                Userrolersp.Msg = "Success";
                return Userrolersp;
            }
            catch (Exception)
            {
                
                Userrolersp.Status = "Fail";
                Userrolersp.Msg = "Fail";
                return Userrolersp; 
            }
        }

        public UserRoleResponse GetUserRole(int id)
        {
            UserRoleResponse Userrolersp = new UserRoleResponse();
            try
            {
                UserRole? GetData = _context.UserRoles.Where(s => s.Id == id).AsQueryable().FirstOrDefault();

                if (GetData != null)
                {
                    Userrolersp._UserRole = GetData;
                }
                Userrolersp.Status = "Success";
                Userrolersp.Msg = "Success";
                return Userrolersp;
            }
            catch (Exception)
            {
                Userrolersp.Status = "Fail";
                Userrolersp.Msg = "Fail";
                return Userrolersp;
            }
        }

        public UserRoleResponse AddUserRole(UserRole _userRoles)
        {
            UserRoleResponse Userrolersp = new UserRoleResponse();
            try
            {
                var AddUserRole = _context.UserRoles.Add(_userRoles);
                _context.SaveChanges();
                Userrolersp.Status = "Success";
                Userrolersp.Msg = "Success";
                Userrolersp._UserRole = AddUserRole.Entity;
                return Userrolersp;
            }
            catch (Exception)
            {
                Userrolersp.Status = "Fail";
                Userrolersp.Msg = "Fail";
                return Userrolersp;
            }
        }
        public UserRoleResponse UpdateUserRole(UserRole _userRole)
        {
            UserRoleResponse Userrolersp = new UserRoleResponse();  
            try
            {
                UserRole? UpdateData = _context.UserRoles.Where(s => s.Id == _userRole.Id).AsQueryable().FirstOrDefault();
                if (UpdateData != null)
                {
                    UpdateData.RoleName = _userRole.RoleName;
                    UpdateData.RoleId = _userRole.RoleId;
                    UpdateData.IsDeleted = _userRole.IsDeleted;
                    UpdateData.CreatedBy = _userRole.CreatedBy;
                    UpdateData.ModifiedBy = _userRole.ModifiedBy;
                    UpdateData.CreatedOn = _userRole.CreatedOn;
                    UpdateData.ModifiedOn = _userRole.ModifiedOn;
                    UpdateData.OrderBy = _userRole.OrderBy;
                    _context.SaveChanges();
                }

                Userrolersp.Status = "Success";
                Userrolersp.Msg = "Success";
                Userrolersp._UserRole = UpdateData;
                return Userrolersp;
            }
            catch (Exception)
            {
                Userrolersp.Status = "Fail";
                Userrolersp.Msg = "Fail";
                return Userrolersp;
            }
        }

        public UserRoleResponse DeleteUserRole(UserRole _userRole)
        {
            UserRoleResponse Userrolersp = new UserRoleResponse();
            try
            {
                UserRole? DeleteData = _context.UserRoles.Where(s => s.Id == _userRole.Id).AsQueryable().FirstOrDefault();
                if (DeleteData != null)
                {
                    DeleteData.IsDeleted = true;
                    _context.SaveChanges();

                    Userrolersp.Status = "Success";
                    Userrolersp.Msg = "Success";
                    Userrolersp._UserRole = DeleteData;
                    return Userrolersp;
                }
                else
                {

                    Userrolersp.Status = "Success";
                    Userrolersp.Msg = "Data Not Found";
                    Userrolersp._UserRole = DeleteData;
                    return Userrolersp;
                }

            }
            catch (Exception)
            {

                Userrolersp.Status = "Fail";
                Userrolersp.Msg = "Fail";
                return Userrolersp;
            }
        }
    }
}
