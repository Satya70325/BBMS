﻿using BBMS.Common.Login;
using BBMS.Common.Models;
using BBMS.Data.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS.Data.Repository
{
    public class UserManagementRepository : IUserManagement
    {
        private readonly BBMSDataContext _context;
        public UserManagementRepository(BBMSDataContext context)
        {
            _context = context;
        }

        /// <summary>
        /// User Management Mechanism
        /// </summary>
        /// <returns></returns>
        public UserManagementResponse GetAllUserManagements()
        {
            UserManagementResponse UserManagmntrsp = new UserManagementResponse();
            try
            {
                List<UserManagement> GetAllUserMgmnt = _context.UserManagements.Where(s => !s.IsDeleted).ToList();

                if (GetAllUserMgmnt.Any())
                {
                    List<UserManagement> response = GetAllUserMgmnt.Select(s => new UserManagement()
                    {
                        Id = s.Id,
                        FirstName = s.FirstName,
                        MiddleName = s.MiddleName,
                        LastName = s.LastName,
                        PrimaryMobile = s.PrimaryMobile,
                        SecondaryMobile = s.SecondaryMobile,
                        PrimaryEmail = s.PrimaryEmail,
                        SecondaryEmail = s.SecondaryEmail,
                        Address1 = s.Address1,
                        Address2 = s.Address2,
                        Address3 = s.Address3,
                        PinCode = s.PinCode,
                        UserName = s.UserName,
                        PassWord = s.PassWord

                    }).ToList();
                    UserManagmntrsp._userManagement = response;
                }
                UserManagmntrsp.Status = "Success";
                UserManagmntrsp.Msg = "Success";
                return UserManagmntrsp;
            }
            catch (Exception)
            {

                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Fail";
                return UserManagmntrsp;
            }
        }
        public UserManagementResponse GetUserManagement(int id)
        {
            UserManagementResponse UserManagmntrsp = new UserManagementResponse();
            try
            {
                UserManagement? GetData = _context.UserManagements.Where(s => s.Id == id).AsQueryable().FirstOrDefault();

                if (GetData != null)
                {
                    UserManagmntrsp._UserMgmt = GetData;
                }
                UserManagmntrsp.Status = "Success";
                UserManagmntrsp.Msg = "Success";
                return UserManagmntrsp;
            }
            catch (Exception)
            {
                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Fail";
                return UserManagmntrsp;
            }
        }
        public UserManagementResponse AddUserManagement(UserManagement _userManagement)
        {
            UserManagementResponse UserManagmntrsp = new UserManagementResponse();
            try
            {
                UserManagement? UpdateData = _context.UserManagements.Where(s => s.UserName == _userManagement.UserName && s.UserRoleId == _userManagement.UserRoleId && !s.IsDeleted).AsQueryable().FirstOrDefault();
                if (UpdateData==null)
                {
                    var AddUserMangmnt = _context.UserManagements.Add(_userManagement);
                    _context.SaveChanges();
                    UserManagmntrsp.Status = "Success";
                    UserManagmntrsp.Msg = "Success";
                    UserManagmntrsp._UserMgmt = AddUserMangmnt.Entity;
                }
                else
                {
                    UserManagmntrsp.Status = "Fail";
                    UserManagmntrsp.Msg = "User already Exits";
                }
                return UserManagmntrsp;
            }
            catch (Exception)
            {
                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Fail";
                return UserManagmntrsp;
            }
        }            
        public UserManagementResponse UpdateUserManagement(UserManagement _userManagement)
        {
            UserManagementResponse UserManagmntrsp = new UserManagementResponse();
            try
            {
                UserManagement? UserValidData = _context.UserManagements.Where(s => s.UserName == _userManagement.UserName && s.UserRoleId == _userManagement.UserRoleId && !s.IsDeleted && s.Id!=_userManagement.Id).AsQueryable().FirstOrDefault();
                if (UserValidData == null)
                {
                    UserManagement? UpdateData = _context.UserManagements.Where(s => s.Id == _userManagement.Id).AsQueryable().FirstOrDefault();
                    if (UpdateData != null)
                    {
                        UpdateData.UserRoleId = _userManagement.UserRoleId;
                        UpdateData.UserRoleRowId = _userManagement.UserRoleRowId;
                         UpdateData.RowId = _userManagement.RowId;
                        UpdateData.FirstName = _userManagement.FirstName;
                        UpdateData.MiddleName = _userManagement.MiddleName;
                        UpdateData.LastName = _userManagement.LastName;
                        UpdateData.PrimaryMobile = _userManagement.PrimaryMobile;
                        UpdateData.SecondaryMobile = _userManagement.SecondaryMobile;
                        UpdateData.PrimaryEmail = _userManagement.PrimaryEmail;
                        UpdateData.SecondaryEmail = _userManagement.SecondaryEmail;
                        UpdateData.Address1 = _userManagement.Address1;
                        UpdateData.Address2 = _userManagement.Address2;
                        UpdateData.Address3 = _userManagement.Address3;
                        UpdateData.PinCode = _userManagement.PinCode;
                        UpdateData.UserName = _userManagement.UserName;
                        UpdateData.PassWord = _userManagement.PassWord;
                        UpdateData.CreatedBy = _userManagement.CreatedBy;
                        UpdateData.ModifiedBy = _userManagement.ModifiedBy;
                        UpdateData.CreatedOn = _userManagement.CreatedOn;
                        UpdateData.ModifiedOn = _userManagement.ModifiedOn;
                        UpdateData.OrderBy = _userManagement.OrderBy;
                        _context.SaveChanges();
                    }

                    UserManagmntrsp.Status = "Success";
                    UserManagmntrsp.Msg = "Success";
                    UserManagmntrsp._UserMgmt = UpdateData;
                   
                }
                else
                {
                    UserManagmntrsp.Status = "Fail";
                    UserManagmntrsp.Msg = "User already Exits";
                }
                return UserManagmntrsp;
            }
            catch (Exception)
            {
                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Fail";
                return UserManagmntrsp;
            }
        }
        public UserManagementResponse DeleteUserManagement(UserManagement _userManagement)
        {
            UserManagementResponse UserManagmntrsp = new UserManagementResponse();
            try
            {
                UserManagement? DeleteData = _context.UserManagements.Where(s => s.Id == _userManagement.Id).AsQueryable().FirstOrDefault();
                if (DeleteData != null)
                {
                    DeleteData.IsDeleted = true;
                    _context.SaveChanges();

                    UserManagmntrsp.Status = "Success";
                    UserManagmntrsp.Msg = "Success";
                    UserManagmntrsp._UserMgmt = DeleteData;
                    return UserManagmntrsp;
                }
                else
                {

                    UserManagmntrsp.Status = "Success";
                    UserManagmntrsp.Msg = "Data Not Found";
                    UserManagmntrsp._UserMgmt = DeleteData;
                    return UserManagmntrsp;
                }

            }
            catch (Exception)
            {

                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Fail";
                return UserManagmntrsp;
            }
        }



        /// <summary>
        /// Login Mechanism
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public LoginReponse GetUserLogin(LoginVM Input)
        {
            LoginReponse UserManagmntrsp = new LoginReponse();
            try
            {
                UserManagement? GetData = _context.UserManagements.Where(s => s.UserName == Input.UserName && 
                                                                              s.PassWord==Input.Password && 
                                                                              !s.IsDeleted && s.UserRoleId==Input.RoleId).AsQueryable().FirstOrDefault();

                if (GetData != null)
                {
                    UserManagmntrsp._userManagement = GetData;
                    UserManagmntrsp.Status = "Success";
                    UserManagmntrsp.Msg = "Login Success";
                    return UserManagmntrsp;
                }
                else
                {
                    UserManagmntrsp.Status = "Fail";
                    UserManagmntrsp.Msg = "Please verify with Account / Contact Admin ";
                }
               
            }
            catch (Exception)
            {
                UserManagmntrsp.Status = "Fail";
                UserManagmntrsp.Msg = "Please verify with Account / Contact Admin ";
                
            }
            return UserManagmntrsp;
        }

    }
}
