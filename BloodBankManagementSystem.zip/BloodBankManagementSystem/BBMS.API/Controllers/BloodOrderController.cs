﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BBMS.API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class BloodOrderController : ControllerBase
    {
        private readonly IBloodOrder bloodOrder;
        public BloodOrderController(IBloodOrder _bloodOrder)
        {
            bloodOrder = _bloodOrder;

        }


        [HttpGet]
        public IActionResult GetAllBloodOrders()
        {
            try
            {
                return Ok(bloodOrder.GetAllBloodOrders());
            }
            catch (Exception)
            {

                throw;
            }

        }


        [HttpGet]
        public IActionResult GetBloodOrder(int Id)
        {
            try
            {
                return Ok(bloodOrder.GetBloodOrder(Id));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult AddBloodOrder([FromBody]BloodOrder _bloodOrder)
        {
            try
            {
                return Ok(bloodOrder.AddBloodOrder(_bloodOrder));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult UpdateBloodOrder([FromBody] BloodOrder _bloodOrder)
        {
            try
            {
                return Ok(bloodOrder.UpdateBloodOrder(_bloodOrder));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult DeleteBloodOrder([FromBody] BloodOrder _bloodOrder)
        {
            try
            {
                return Ok(bloodOrder.DeleteBloodOrder(_bloodOrder));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }
    }
}
