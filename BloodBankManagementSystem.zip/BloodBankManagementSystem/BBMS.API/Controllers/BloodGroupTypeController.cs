﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BBMS.API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class BloodGroupTypeController : ControllerBase
    {
        private readonly IBloodGroupType bloodGroupType;
        public BloodGroupTypeController(IBloodGroupType _bloodGroupType)
        {
            bloodGroupType = _bloodGroupType;

        }


        [HttpGet]
        public IActionResult GetAllBloodGroupTypes()
        {
            try
            {
                return Ok(bloodGroupType.GetAllBloodGroupTypes());
            }
            catch (Exception)
            {

                throw;
            }

        }


        [HttpGet]
        public IActionResult GetBloodGroupType(int Id)
        {
            try
            {
                return Ok(bloodGroupType.GetBloodGroupType(Id));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult AddBloodGroupType(BloodGroupType _bloodGT)
        {
            try
            {
                return Ok(bloodGroupType.AddBloodGroupType(_bloodGT));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult UpdateBloodGroupType(BloodGroupType _bloodGT)
        {
            try
            {
                return Ok(bloodGroupType.UpdateBloodGroupType(_bloodGT));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult DeleteBloodGroupType(BloodGroupType _bloodGT)
        {
            try
            {
                return Ok(bloodGroupType.DeleteBloodGroupType(_bloodGT));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }
    }
}
