﻿using BBMS.Common.Login;
using BBMS.Common.Models;
using BBMS.Data.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BBMS.API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UserManagementController : ControllerBase
    {
        private readonly IUserManagement userManagement;
        public UserManagementController(IUserManagement _userManagement)
        {
            userManagement = _userManagement;

        }

        [HttpGet]
        public IActionResult GetAllUsermanagement()
        {
            try
            {
                return Ok(userManagement.GetAllUserManagements());
            }
            catch (Exception)
            {

                throw;
            }

        }
        [HttpGet]
        public IActionResult GetUserUsermanagement(int Id)
        {
            try
            {
                return Ok(userManagement.GetUserManagement(Id));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }
        [HttpPost]
        public IActionResult AddUsermanagement(UserManagement _userMgnt)
        {
            try
            {
                return Ok(userManagement.AddUserManagement(_userMgnt));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }
        [HttpPost]
        public IActionResult UpdateUsermanagement(UserManagement _userMgnt)
        {
            try
            {
                return Ok(userManagement.UpdateUserManagement(_userMgnt));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }
        [HttpPost]
        public IActionResult DeleteUsermanagement(UserManagement _userMgnt)
        {
            try
            {
                return Ok(userManagement.DeleteUserManagement(_userMgnt));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }

        /// <summary>
        /// Login Mechanism
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult GetUserLogin([FromBody]LoginVM Input)
        {
            try
            {
                return Ok(userManagement.GetUserLogin(Input));
            }
            catch (Exception)
            {
                return Ok(null);
            }
           
        }
    }
}
