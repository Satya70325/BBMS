﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BBMS.API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UserRoleController : ControllerBase
    {
        private readonly IUserRoleRepository userRoleRepository;
        public UserRoleController(IUserRoleRepository _userRoleRepository)
        {
            userRoleRepository = _userRoleRepository;

        }


        [HttpGet]
        public IActionResult GetAllRoles()
        {
            try
            {
                return Ok(userRoleRepository.GetAllUserRole());
            }
            catch (Exception)
            {

                throw;
            }
            
        }


        [HttpGet]
        public IActionResult GetUserRole(int Id)
        {
            try
            {
                return Ok(userRoleRepository.GetUserRole(Id));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }
        

        [HttpPost]
        public IActionResult AddRolet(UserRole _userRole)
        {
            try
            {
                return Ok(userRoleRepository.AddUserRole(_userRole));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult UpdateRole(UserRole _userRole)
        {
            try
            {
                return Ok(userRoleRepository.UpdateUserRole(_userRole));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult DeleteRole(UserRole _userRole)
        {
            try
            {
                return Ok(userRoleRepository.DeleteUserRole(_userRole));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }
    }
}
