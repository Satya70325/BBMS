﻿using BBMS.Common.Models;
using BBMS.Data.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BBMS.API.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class BloodDonationController : ControllerBase
    {
        private readonly IBloodDonation bloodDonation;
        public BloodDonationController(IBloodDonation _bloodDonation)
        {
            bloodDonation = _bloodDonation;

        }


        [HttpGet]
        public IActionResult GetAllBloodDonations()
        {
            try
            {
                return Ok(bloodDonation.GetAllBloodDonars());
            }
            catch (Exception)
            {

                throw;
            }

        }


        [HttpGet]
        public IActionResult GetBloodDonation(int Id)
        {
            try
            {
                return Ok(bloodDonation.GetBloodDonar(Id));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult AddBloodDopnation(BloodDonation _bloodDonation)
        {
            try
            {
                return Ok(bloodDonation.AddBloodDonar(_bloodDonation));
            }
            catch (Exception)
            {

                throw;
            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult UpdateBloodDonation(BloodDonation _bloodDonation)
        {
            try
            {
                return Ok(bloodDonation.UpdateBloodDonar(_bloodDonation));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }


        [HttpPost]
        public IActionResult DeleteBloodDonation(BloodDonation _bloodDonation)
        {
            try
            {
                return Ok(bloodDonation.DeleteBloodDonar(_bloodDonation));
            }
            catch (Exception)
            {


            }
            return Ok(null);
        }
    }
}
